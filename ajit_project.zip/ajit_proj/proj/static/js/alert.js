$(function() {
    setTimeout(function() { $("#alert").fadeOut(1500); }, 5000)
    
    })
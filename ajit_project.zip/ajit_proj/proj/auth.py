from flask import Blueprint, flash, redirect, render_template, request, url_for
from . import db 
from .models import User 
from werkzeug.security import generate_password_hash, check_password_hash



auth = Blueprint('auth', __name__)



@auth.route('/' , methods=['GET', 'POST']) 

def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']


        user = User.query.filter_by(username=username).first()

        if user:
            if check_password_hash(user.password, password):
                flash('Logged in successfully!', category='success')
                return redirect(url_for('views.alarm'))
            else:
                flash('Incorrect password, try again.', category='error')
        else:
            flash('Email does not exist.', category='error')

    return render_template("loginpage.html")


@auth.route('/register', methods=['GET', 'POST']) 

def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password= request.form['psw-repeat']
        user = User.query.filter_by(username=username).first()
        if user:
            flash('Email already exists.', category='error')
        elif len(username) < 4:
            flash('Email must be greater than 3 characters.', category='error')
        elif password != confirm_password:
            flash('Passwords don\'t match.', category='error')
        elif len(password) < 7:
            flash('password must be at least 7 characters.', category='error')


        else:
            new_user = User(username=username,password= generate_password_hash(password ,method='sha256'))
            db.session.add(new_user)
            db.session.commit()
            flash('account created')
            return redirect(url_for('auth.login'))


    return render_template('registration.html')

from flask import Blueprint, render_template



views = Blueprint('views', __name__)

@views.route('/world_clock') 
def world():
    return render_template('world_clock.html')


@views.route('/index')
def home():
	return render_template('index.html')



@views.route('/alarm') 
def alarm():
    return render_template("js-alarm-clock.html")
